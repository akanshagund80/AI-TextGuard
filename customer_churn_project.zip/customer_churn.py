import pandas as pd
import numpy as np
import joblib
from flask import Flask, request, jsonify
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler, LabelEncoder
from sklearn.ensemble import RandomForestClassifier

# Load dataset
df = pd.read_csv('customer_churn.csv')

# Data Preprocessing
df.dropna(inplace=True)

# Encode categorical features
le = LabelEncoder()
df['Gender'] = le.fit_transform(df['Gender'])
df['Partner'] = le.fit_transform(df['Partner'])
df['Dependents'] = le.fit_transform(df['Dependents'])
df['Churn'] = le.fit_transform(df['Churn'])

# Feature Selection
X = df.drop(columns=['Churn', 'customerID'])
y = df['Churn']

# Split Data
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Standardize features
scaler = StandardScaler()
X_train = scaler.fit_transform(X_train)
X_test = scaler.transform(X_test)

# Model Training
model = RandomForestClassifier(n_estimators=100, random_state=42)
model.fit(X_train, y_train)

# Save Model and Scaler
joblib.dump(model, 'churn_model.pkl')
joblib.dump(scaler, 'scaler.pkl')

# Flask App
app = Flask(__name__)

@app.route('/predict', methods=['POST'])
def predict():
    data = request.get_json()
    input_data = np.array(data['features']).reshape(1, -1)
    input_data = joblib.load('scaler.pkl').transform(input_data)
    prediction = joblib.load('churn_model.pkl').predict(input_data)
    return jsonify({'Churn Prediction': int(prediction[0])})

if __name__ == '__main__':
    app.run(debug=True)
