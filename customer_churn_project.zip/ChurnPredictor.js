import React, { useState } from "react";
import axios from "axios";

const ChurnPredictor = () => {
  const [features, setFeatures] = useState("");
  const [prediction, setPrediction] = useState(null);

  const handleChange = (event) => {
    setFeatures(event.target.value);
  };

  const handleSubmit = async () => {
    const featureArray = features.split(",").map(Number);
    try {
      const response = await axios.post("http://127.0.0.1:5000/predict", {
        features: featureArray,
      });
      setPrediction(response.data["Churn Prediction"]);
    } catch (error) {
      console.error("Error fetching prediction:", error);
    }
  };

  return (
    <div className="p-6 max-w-md mx-auto bg-white rounded-xl shadow-md space-y-4">
      <h1 className="text-xl font-bold">Customer Churn Predictor</h1>
      <input
        type="text"
        placeholder="Enter features comma-separated"
        value={features}
        onChange={handleChange}
        className="border p-2 w-full"
      />
      <button
        onClick={handleSubmit}
        className="bg-blue-500 text-white px-4 py-2 rounded"
      >
        Predict
      </button>
      {prediction !== null && (
        <p className="mt-4 text-lg font-semibold">Prediction: {prediction === 1 ? "Churn" : "No Churn"}</p>
      )}
    </div>
  );
};

export default ChurnPredictor;
