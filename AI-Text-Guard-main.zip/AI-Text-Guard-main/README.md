# AI-Text-Guard
AI TextGuard is a tool designed to detect AI-generated vs. human-written text. It uses machine learning models trained with scikit-learn to analyze text patterns and classify content accurately.Built with Flask (backend) and React.js (frontend).The project aims to enhance content authenticity detection for researchers, educators, and businesses. 🚀
